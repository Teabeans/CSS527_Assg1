g++ *.cpp -std=c++11 -o assg1.o
./assg1.o
rm assg1.o
